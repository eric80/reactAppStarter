import {connect} from 'react-redux';
import ColorView from './ColorView';

export default connect()(ColorView);
