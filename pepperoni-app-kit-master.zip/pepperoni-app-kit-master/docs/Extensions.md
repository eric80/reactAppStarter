# Extensions

This section is for different variations you can do on the Pepperoni Framework.
If you have something cool to contribute please feel free to submit a PR!
